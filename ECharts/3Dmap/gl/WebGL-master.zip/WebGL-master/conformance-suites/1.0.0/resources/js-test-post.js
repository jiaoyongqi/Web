shouldBeTrue("successfullyParsed");
debug('<br /><span class="pass">TEST COMPLETE</span>');
notifyFinishedToHarness()
