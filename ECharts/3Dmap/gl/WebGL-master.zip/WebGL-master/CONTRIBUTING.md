# If you need help with WebGL please use [stackoverflow](http://stackoverflow.com/questions/tagged/webgl).

How to contribute to the WebGL conformance tests.
---
1. Make sure you have a GitHub account.
2. Fork the repository on GitHub.
3. Check the [Contribution Guidelines](sdk/tests/test-guidelines.md).
4. Make changes to your clone of the repository.
5. Submit a pull request.


