import DataZoomView from './DataZoomView';

export default DataZoomView.extend({
    type: 'dataZoom.select'
});